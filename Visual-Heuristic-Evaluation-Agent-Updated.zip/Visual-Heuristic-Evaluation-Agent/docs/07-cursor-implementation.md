# 07 — Cursor Implementation Playbook

## Source-of-truth hierarchy

Use these in order:

1. `PRD.md` — WHAT the product is
2. `docs/02-consolidated-agentic-experience.md` — HOW the experience flows
3. `docs/03-detailed-stage-specifications.md` — EXACT stage behavior
4. `docs/04-heuristic-evaluation-rules.md` — HOW evaluation works
5. `docs/05-finding-data-schema.md` — DATA CONTRACT
6. `docs/06-figma-mvp.md` — UI reference
7. `docs/07-cursor-implementation.md` — BUILD SEQUENCE

If documents conflict, do not invent a solution. Flag the conflict and use the higher-level document.

## Recommended project structure

```text
visual-heuristic-evaluation-agent/
├── PRD.md
├── docs/
│   ├── 02-consolidated-agentic-experience.md
│   ├── 03-detailed-stage-specifications.md
│   ├── 04-heuristic-evaluation-rules.md
│   ├── 05-finding-data-schema.md
│   ├── 06-figma-mvp.md
│   └── 07-cursor-implementation.md
├── design/
│   └── figma-reference.md
└── src/
```

## Implementation strategy

Do not ask Cursor to build the complete autonomous agent in one prompt.

Use this sequence:

```text
Documents
→ State model
→ UI shell
→ Mock agent
→ Risk hypothesis model
→ Finding model
→ Heuristic evaluator
→ Visual evidence
→ Human review
→ Fallback
→ Real integrations
→ Validation
```

## Step 1 — Read the product source of truth

Give Cursor:

- `PRD.md`
- `docs/02-consolidated-agentic-experience.md`
- `docs/03-detailed-stage-specifications.md`
- `docs/04-heuristic-evaluation-rules.md`
- `docs/05-finding-data-schema.md`
- `docs/06-figma-mvp.md`

Prompt:

> Read all supplied documents. Do not write code yet. Summarize the product boundary, visible journey, internal state model, risk-vs-finding distinction, data contract, and Figma mapping. Identify contradictions or missing backend dependencies.

## Step 2 — Build the state model

Expected visible states:

```text
setup
→ analyzing
→ risk_preview
→ review
→ completed
```

Important branches:

```text
setup
→ clarification_required
→ setup

analyzing
→ error/recovery
→ analyzing

risk_preview
→ needs_evidence
→ validated
→ review

review
→ kept / edited / dismissed
→ report
```

The implementation should not expose every internal state as a separate screen.

## Step 3 — Build the UI shell first

Use the revised V5 Figma design as the visual reference.

Prompt:

> Build the visible MVP states from `docs/06-figma-mvp.md`. Do not implement real AI or external tools yet. Use deterministic mock data so the complete clickable experience works: Set up → Analyze → Risk Preview → Review → Report. Keep fallback inline.

## Step 4 — Add deterministic mock agent behavior

Implement mock behavior for:

- intent understanding;
- conditional clarification;
- target access;
- screen capture;
- analysis progress;
- risk prediction;
- evidence validation;
- finding generation;
- review decisions.

The mock should demonstrate the distinction:

```text
risk hypothesis
→ needs evidence OR validated
→ finding only when validated
```

## Step 5 — Implement the risk model before the finding UI

Give Cursor:

`docs/05-finding-data-schema.md`

Prompt:

> Implement separate typed models for evaluation, screens, risk hypotheses, and validated findings. A risk hypothesis must not receive final finding severity. Preserve `riskId → findingId` traceability when a hypothesis becomes a finding.

## Step 6 — Implement heuristic evaluation

Give Cursor:

`docs/04-heuristic-evaluation-rules.md`

Prompt:

> Implement the heuristic evaluator as a separate module. It should inspect available evidence, identify supported usability issues, map them to Nielsen's heuristics, assign severity only after evidence supports the issue, and produce finding objects. Do not mix evaluation logic into UI components.

## Step 7 — Add visual evidence

Prompt:

> Connect finding objects to the visual finding UI. Every validated finding must identify the affected screen and highlight region. Display evidence, observation, heuristic, severity, impact, recommendation, and suggested improvement together.

## Step 8 — Add human review

Prompt:

> Implement Keep, Edit, and Dismiss. Only kept or edited findings appear in the final report. Dismissed findings remain excluded. Preserve the original risk hypothesis trace when applicable.

## Step 9 — Add fallback

Prompt:

> Implement only the documented target-access fallback: Provide screenshot, Edit URL, Try again, or Go back. Preserve the current evaluation goal and session context. Do not create a dead-end error screen.

## Step 10 — Replace mocks with real integrations

Only after the complete experience works:

> Replace mock capture/evaluation behavior with real resource/tool integrations. Preserve the visible state model, risk-vs-finding distinction, finding schema, severity scale, evidence traceability, and human-review flow.

Do not invent backend APIs.

## Step 11 — Requirements audit

Prompt:

> Audit the implementation against `PRD.md` and every document in `docs/`. Report implemented requirements, missing requirements, workflow deviations, unsupported assumptions, and features outside MVP. Do not change code yet.

## Step 12 — Visual QA against Figma

Only after functional behavior works.

Prompt:

> Compare the implementation against the revised V5 Figma design. Check layout, typography, spacing, navigation, state labels, risk-vs-finding distinction, evidence presentation, severity, review controls, report hierarchy, fallback behavior, accessibility, and responsive behavior. List differences before making changes.

Then apply only approved visual fixes.

## Cursor project rules

1. Follow `PRD.md` as the product source of truth.
2. Follow the consolidated agentic experience for behavior.
3. Follow the stage specifications for exact behavior.
4. Follow the heuristic rules for evaluation logic.
5. Follow the finding/risk schema for data structure.
6. Follow Figma for visual design.
7. Reuse existing application components and design systems.
8. Do not invent backend APIs.
9. Do not expose chain-of-thought.
10. Do not turn predictions into findings without evidence.
11. Do not assign final severity to unresolved risk hypotheses.
12. Do not count `needs_evidence` hypotheses as findings.
13. Preserve `riskId → findingId` traceability.
14. Keep business logic separate from UI components.
15. Implement one functional behavior at a time.
16. Do not modify unrelated functionality.
17. Preserve accessibility and keyboard interaction.
18. Keep mock data isolated from production services.
19. If a requirement is ambiguous, flag it before making a product decision.
20. After each implementation, report files changed and requirements addressed.

## Recommended working method

For each Cursor session:

```text
1. Give Cursor ONE task.
2. Ask it to inspect the existing code first.
3. Ask for a plan.
4. Review the plan.
5. Allow implementation.
6. Run/test the feature.
7. Ask Cursor what changed.
8. Compare against Figma.
9. Audit against the source-of-truth docs.
10. Move to the next task.
```

Avoid:

```text
Build the complete autonomous heuristic agent from this Figma.
```

Prefer:

```text
Implement the Set up state only.
First inspect the existing code and design system.
Then explain the implementation approach.
Implement only the documented behavior.
Do not modify unrelated functionality.
```
