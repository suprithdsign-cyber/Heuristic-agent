# 06 — Figma MVP Specification

## Current Figma source

Figma file:

https://www.figma.com/design/UkFGLSaPcxHiIz7JGYF5Ez/Heuristic-Analysis-Agent-%25E2%2580%2594-MVP?node-id=73-4

The current implementation reference is the **revised V5 flow** in the existing file.

## Current visible screens

```text
V5 01 — Set up
V5 02 — Analyze
V5 03 — Risk preview
V5 04 — Review findings
V5 05 — Report
```

Fallback is represented as a continuation/recovery state rather than a separate primary stage.

## Process-to-screen mapping

| Process stage | Figma screen | User sees | Agent state |
|---|---|---|---|
| 01 Set up | V5 01 — Set up | Target, goal, detected screens, scope readiness | setup |
| 02 Analyze | V5 02 — Analyze | Capture/evaluation progress and evidence collection | analyzing |
| 03 Risk preview | V5 03 — Risk preview | Potential risk areas and validation boundary | risk_preview |
| 04 Review | V5 04 — Review findings | One validated finding with evidence + decision controls | review |
| 05 Report | V5 05 — Report | Connected findings/evidence + Improvement Plan | completed/report |
| Fallback | Inline/continuation | Screenshot, Edit URL, Retry, Go back | error/recovery |

## Set up screen

The setup screen should:

- accept URL or screenshots;
- show detected/captured screens when available;
- capture the user's goal;
- indicate when scope is clear;
- start evaluation;
- keep clarification conditional rather than always visible.

Do not recreate the old multi-screen “Understand / Check / Clarify” journey as separate primary screens.

## Analyze screen

Show useful progress such as:

- screens captured;
- journey mapped;
- heuristic evaluation progress;
- evidence collected;
- potential risk areas discovered.

Do not expose private reasoning.

## Risk preview screen

This is the main new value-add in the revised V5 flow.

Show:

- potential risk area;
- why it deserves attention;
- relevant heuristic area;
- status such as **Needs evidence** when not yet supported;
- clear statement that predictions are hypotheses.

When evidence supports the risk, the state may become **Risk validated** and move into Review.

### Important UI rule

Do not present “Needs evidence” as a normal finding count.

For example, avoid:

```text
Finding 02 of 04
Needs validation
```

when the item is still only a hypothesis.

Prefer:

```text
Potential risk
Needs evidence
```

Then count only validated findings in the Review stage.

## Review findings screen

Each finding is self-contained:

```text
Finding title
Severity
Heuristic
Screen

Visual evidence + highlighted region

Observation
Why it matters
Heuristic rationale
Evidence

Recommendation
Suggested improvement

Keep / Edit / Dismiss
```

The review context may also show the originating prediction and indicate that it was validated by evidence.

## Report screen

Primary report structure:

```text
Executive Summary
↓
Findings & Evidence
↓
Improvement Plan
↓
Evaluation Context
↓
Methodology
```

The Evidence Index can exist as a secondary navigation utility.

Do not separate one issue's evidence into an Evidence Gallery and its solution into a disconnected Recommendations page.

## Design evolution

### V2

Explicit Start → Clarify → Analyze → Visual Findings → Visual Report → Fallback.

### V3

Simplified clarification and progress; removed redundant scope UI; strengthened human control.

### V4

Cleaned the MVP around Start → Clarify → Analyze → Review → Report, with fallback in-session.

### V5 exploration

Introduced a richer Target → Goal → Analyze → Review → Report experience and explored prediction, release weighting, impact prediction, and conversational follow-up.

### Revised V5

The design was simplified again:

```text
Set up → Analyze → Risk preview → Review → Report
```

The prediction layer remains because it provides useful focus, but numeric confidence, predicted business impact, release weighting, and follow-up optimization were removed from the MVP.

### V6 exploration

A later simplification explored:

```text
Set up → Analyze → Review → Report
```

with fallback as continuation. This validated that the overall journey could be even more compact, but the **revised V5 with Risk Preview is the current source of truth** because it retains the agreed value-add prediction layer.

## Design principles

- Evidence before assertion.
- Prediction is not proof.
- User and agent actions must be visually distinguishable.
- Agent status must be concise.
- Findings must be anchored to visual evidence.
- Evidence and recommendation for a finding stay connected.
- User controls important final decisions.
- Do not add unnecessary product features.
- Do not expose chain-of-thought.
