# 08 — Case Study Takeaway: Visual Heuristic Evaluation Agent

## Case-study positioning

This project can be presented as an exploration of **how AI can augment UX evaluation without replacing designer judgment**.

The strongest narrative is not simply that an AI agent performs heuristic analysis. The design challenge was to make the agent useful, evidence-grounded, transparent enough to trust, and simple enough for a UX designer to control.

## 1. The problem

Traditional heuristic evaluation can become:

- time-consuming;
- text-heavy;
- difficult to scan;
- disconnected from the actual UI;
- inconsistent in how findings are communicated.

The AI opportunity was to accelerate the repetitive analysis work while preserving the designer's ability to judge whether an issue is real, important, and actionable.

## 2. Design challenge

The key challenge became:

> How might an AI agent help a designer discover and validate usability problems faster without turning plausible AI assumptions into unsupported findings?

This led to the core principle:

```text
AI accelerates analysis.
Designer owns judgment.
```

## 3. Exploration process

### Step 1 — Define the product boundary

Started with the concept of a Visual Heuristic Evaluation Agent and established:

- primary user: UX/Product Designer;
- target: URL, screens, or screenshots;
- framework: Nielsen's 10 heuristics;
- output: visual, evidence-linked findings;
- human review before final reporting.

### Step 2 — Convert the concept into an agentic workflow

The initial thinking separated many internal stages:

```text
Start
→ Understand intent
→ Check required information
→ Clarify
→ Access resource
→ Perform evaluation
→ Communicate status
→ Present result
→ Confirm
```

This was useful for defining agent behavior but too detailed to expose directly as the main product navigation.

### Step 3 — Simplify the visible journey

Through repeated Figma revisions, the detailed internal stages were grouped into a simpler designer-facing journey:

```text
Set up → Analyze → Review → Report
```

A further value-add was then introduced as a focused **Risk Preview** stage:

```text
Set up → Analyze → Risk Preview → Review → Report
```

### Step 4 — Explore AI-specific value

A richer V5 exploration tested ideas such as:

- predicted evaluation scope;
- prediction confidence;
- “what matters most for this release?” weighting;
- predicted business impact;
- conversational prioritization.

These ideas helped explore the potential of an agentic experience, but the MVP became clearer when the scope was reduced.

The decision was to keep one useful prediction capability:

> **Predict where usability risk may exist so the designer knows where to look first.**

### Step 5 — Establish the prediction boundary

A critical distinction emerged:

```text
Prediction ≠ Finding
```

The resulting model:

```text
Risk hypothesis
      ↓
Visual evidence
      ↓
Risk validated?
  ┌───────┴───────┐
 Yes              No
  ↓                ↓
Finding       Needs evidence
  ↓
Human review
```

This prevents an AI-generated hypothesis from automatically becoming a usability conclusion.

### Step 6 — Rework the finding/report experience

The report was identified as a major UX issue during iteration.

A disconnected structure such as:

```text
Findings
→ Evidence Gallery
→ Recommendations
```

made it difficult to understand one issue at a glance.

The report was therefore redesigned around the **finding as the primary unit**:

```text
Finding
├── Visual evidence
├── Observation
├── Heuristic
├── Severity
├── Why it matters
├── Recommendation
└── Suggested improvement
```

The Improvement Plan became a synthesis layer rather than a separate place where the designer must go to understand the solution.

### Step 7 — Strengthen human control

Every validated finding is reviewed before entering the final report:

```text
Keep
Edit
Dismiss
```

This creates a clear boundary between AI assistance and designer ownership.

### Step 8 — Design failure recovery as part of the experience

URL access can fail because a page is inaccessible, authenticated, blocked, or cannot be captured.

Instead of creating a dead-end error state, the flow preserves the session and offers:

```text
Provide screenshot
Edit URL
Try again
Go back
```

## 4. Final product model

```text
                    ┌──────────────┐
                    │   SET UP     │
                    │ Target + goal│
                    └──────┬───────┘
                           ↓
                    ┌──────────────┐
                    │   ANALYZE    │
                    │ Capture +    │
                    │ evaluate     │
                    └──────┬───────┘
                           ↓
                    ┌──────────────┐
                    │ RISK PREVIEW │
                    │ Predict risk │
                    │ not findings │
                    └──────┬───────┘
                           ↓
                    ┌──────────────┐
                    │    REVIEW    │
                    │ Evidence +   │
                    │ human control │
                    └──────┬───────┘
                           ↓
                    ┌──────────────┐
                    │    REPORT    │
                    │ Findings +   │
                    │ action plan  │
                    └──────────────┘
```

## 5. Key UX decisions and why they matter

| Decision | Reasoning |
|---|---|
| Simplified visible journey | Reduces cognitive load while preserving internal agent logic |
| Conditional clarification | Avoids unnecessary setup questions |
| Risk Preview | Adds AI value without pretending prediction is proof |
| Needs evidence state | Makes uncertainty visible and prevents false findings |
| Risk validated state | Creates a clear bridge from prediction to evidence |
| Finding as primary report unit | Keeps evidence and recommendation connected |
| Keep/Edit/Dismiss | Preserves designer judgment |
| Inline fallback | Prevents access failure from becoming a dead end |
| No numeric prediction confidence in MVP | Avoids creating false precision before trust is established |
| No predicted business impact in MVP | Keeps the product focused on evidence-grounded UX evaluation |
| No autonomous redesign | Keeps the agent within a defensible evaluation role |

## 6. What the design process demonstrates

### Product thinking

The work moved from a broad AI concept toward a deliberately constrained MVP.

### Agentic UX thinking

The design distinguishes between:

- what the user does;
- what the agent decides;
- what the system/tool does;
- what requires evidence;
- what requires human judgment.

### UX information architecture

The report structure was reconsidered around the user's real question:

> “What is the problem, where is it, why does it matter, and what should I do about it?”

### AI UX principles

The project demonstrates:

- user-centered autonomy;
- explainability through evidence rather than hidden reasoning;
- user control and fallback;
- progressive disclosure;
- traceability;
- uncertainty handling.

## 7. What should be claimed carefully

This project currently demonstrates a **design/prototype concept and implementation blueprint**.

Unless additional research or engineering evidence is produced, do not claim that:

- designers were proven to work faster;
- the predictions are statistically accurate;
- the recommendations improve task completion;
- the product has validated business impact;
- users preferred one version over another.

Those would require usability testing, comparative evaluation, or production evidence.

## 8. Suggested case-study structure

```text
01 Context
What problem was I solving?

02 Opportunity
Why use an AI agent for heuristic evaluation?

03 Challenge
How do we accelerate evaluation without replacing designer judgment?

04 Exploration
How the agent flow evolved from detailed stages to a simple visible journey.

05 AI UX decision
Why Risk Preview was introduced as a hypothesis layer.

06 Evidence model
How prediction becomes a finding only after validation.

07 Finding/report redesign
Why the finding became the primary report unit.

08 Human control
Keep / Edit / Dismiss and the role of the designer.

09 Failure recovery
How inaccessible targets are handled without losing context.

10 Final MVP
Set up → Analyze → Risk Preview → Review → Report.

11 Prototype / implementation
Figma flow, data schema, Cursor implementation approach.

12 Learnings
What changed in my thinking about agentic UX.

13 Next steps
Research, usability testing, real browser capture, heuristic validation, and future prediction capabilities.
```

## 9. Portfolio-ready summary

> **Visual Heuristic Evaluation Agent**
>
> I designed an AI-assisted heuristic evaluation experience that helps UX designers inspect interfaces faster while keeping human judgment at the center. I explored the agent workflow from intent understanding and resource access through visual evaluation, then simplified it into a focused MVP: **Set up → Analyze → Risk Preview → Review → Report**.
>
> The key design decision was to treat AI predictions as hypotheses rather than findings. A predicted risk must be supported by visual evidence before becoming a finding, and every validated finding remains under designer control through Keep, Edit, or Dismiss. I also redesigned the report around the finding itself so evidence, heuristic rationale, severity, impact, and recommendation remain connected.

## 10. Interview takeaway

A concise way to explain the project:

> “The interesting part wasn't just using AI to run a heuristic evaluation. The challenge was deciding where AI should be autonomous and where the designer should remain in control. I ended up using AI for exploration and risk prediction, evidence for validation, and the designer for final judgment. That principle shaped the entire flow, data model, review experience, and report.”

## 11. Next research / validation opportunities

If this moves beyond the prototype, the next evidence to collect would be:

1. Usability test the Set up → Risk Preview → Review journey with UX designers.
2. Test whether **Needs evidence** and **Risk validated** are immediately understood.
3. Compare connected findings against a separated evidence/recommendation report structure.
4. Measure time-to-first-useful-finding and time-to-final-report.
5. Test false-positive and false-negative patterns in risk prediction.
6. Evaluate the quality and consistency of visual evidence highlighting.
7. Test URL access and fallback scenarios.
8. Only after evidence supports the core workflow, explore confidence, impact prediction, and prioritization features.
