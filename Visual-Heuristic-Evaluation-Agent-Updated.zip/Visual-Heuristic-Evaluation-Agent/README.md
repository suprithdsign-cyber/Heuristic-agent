# Visual Heuristic Evaluation Agent — MVP Source-of-Truth Package

This package captures the current product, agentic UX, evaluation logic, data contract, Figma design direction, Cursor implementation approach, and case-study narrative for the Visual Heuristic Evaluation Agent.

## Current approved MVP journey

```text
SET UP → ANALYZE → RISK PREVIEW → REVIEW → REPORT
```

The key agentic loop is:

```text
Predict risk → Validate with evidence → Create validated finding → Human review
```

**A prediction is not a finding.**

A risk hypothesis that lacks sufficient evidence remains a hypothesis and should be labeled **Needs evidence**. Only evidence-supported risks become findings and enter the finding-review stage.

## What changed through the design iterations

The experience evolved from a more explicit multi-stage agent flow into a simpler designer-facing MVP:

```text
Earlier exploration:
Start → Understand → Check → Clarify → Access → Evaluate → Status → Result → Confirm

Current visible MVP:
Set up → Analyze → Risk preview → Review → Report
```

The detailed internal stages still exist as behavioral contracts, but they are intentionally grouped into fewer visible product stages.

## Reading order

1. `PRD.md` — WHAT the product is
2. `docs/02-consolidated-agentic-experience.md` — HOW the experience flows
3. `docs/03-detailed-stage-specifications.md` — EXACT behavior by stage
4. `docs/04-heuristic-evaluation-rules.md` — EVALUATION LOGIC
5. `docs/05-finding-data-schema.md` — DATA CONTRACT
6. `docs/06-figma-mvp.md` — CURRENT FIGMA MVP REFERENCE
7. `docs/07-cursor-implementation.md` — BUILD SEQUENCE
8. `docs/08-case-study-takeaway.md` — CASE-STUDY / PORTFOLIO NARRATIVE
9. `design/figma-reference.md` — Figma source and design decisions

## Source-of-truth hierarchy

```text
PRD
  ↓
Consolidated Agentic Experience
  ↓
Detailed Stage Specifications
  ↓
Heuristic Evaluation Rules
  ↓
Finding / Risk Data Schema
  ↓
Figma MVP
  ↓
Cursor Implementation
```

If two documents conflict, use the higher-level document and flag the conflict rather than inventing a new behavior.

## Current design decisions

- Keep the primary journey simple: **Set up → Analyze → Risk preview → Review → Report**.
- Combine understanding, required-information checking, and clarification into setup behavior rather than separate primary screens.
- Keep clarification conditional and minimal: ask one concise question only when essential information is missing or materially ambiguous.
- Use risk prediction as the main value-add beyond traditional heuristic evaluation: it helps the designer know where to look first.
- Treat prediction as a **hypothesis**, never as proof.
- Use **Needs evidence** for unresolved risk hypotheses.
- Use **Risk validated / Validated finding** only when captured visual evidence supports the predicted risk.
- Do not show unresolved hypotheses as normal findings.
- Do not assign finding severity to an unvalidated risk hypothesis.
- Keep evidence, issue, heuristic, severity, impact, and recommendation together in each finding.
- Keep human review explicit: **Keep / Edit / Dismiss**.
- Keep fallback within the same session.
- Do not expose chain-of-thought or private reasoning.
- Keep predictive business-impact percentages, numeric confidence scores, release optimization, and conversational prioritization out of the MVP.

## Report principle

The **finding is the primary unit of the report**.

A designer should not need to move between an evidence gallery and a separate recommendation page to understand one issue. Evidence, observation, heuristic, severity, impact, recommendation, and suggested improvement should remain connected.

The Improvement Plan is a secondary synthesis of the reviewed findings, not a replacement for the finding itself.

## Current Figma

The revised V5 flow is maintained in the existing Figma file:

https://www.figma.com/design/UkFGLSaPcxHiIz7JGYF5Ez/Heuristic-Analysis-Agent-%25E2%2580%2594-MVP?node-id=73-4

The file also contains earlier V2–V4 explorations and a V6 simplification exploration. The **revised V5 flow is the current implementation reference for this package** unless explicitly promoted later.

## Recommended Cursor usage

Do not ask Cursor to build the autonomous agent in one prompt. Build in small, traceable steps and validate each layer against the source-of-truth documents and the Figma reference.

## Case-study takeaway

The strongest story is not “I designed a heuristic tool.” It is:

> **I explored how an AI agent could make heuristic evaluation faster without making the designer surrender judgment. I progressively simplified the journey, introduced risk prediction as a hypothesis layer, connected every finding to visual evidence and recommendations, and kept the designer in control of what becomes part of the final report.**
