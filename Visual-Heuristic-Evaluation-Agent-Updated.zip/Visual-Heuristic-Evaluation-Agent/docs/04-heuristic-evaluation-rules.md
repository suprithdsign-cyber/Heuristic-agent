# 04 — Heuristic Evaluation Rules

## Framework

Use Nielsen's 10 usability heuristics:

1. Visibility of system status
2. Match between system and the real world
3. User control and freedom
4. Consistency and standards
5. Error prevention
6. Recognition rather than recall
7. Flexibility and efficiency of use
8. Aesthetic and minimalist design
9. Help users recognize, diagnose, and recover from errors
10. Help and documentation

## Evaluation model

The evaluation has two distinct layers:

```text
RISK PREDICTION
     ↓
EVIDENCE VALIDATION
     ↓
HEURISTIC FINDING
```

Prediction helps focus attention. It does not replace heuristic evaluation.

## Evaluation process

For each captured screen and relevant flow relationship:

1. Inspect visible UI and interaction states.
2. Identify observable evidence.
3. Surface potential risk hypotheses where useful.
4. Check each hypothesis against the captured evidence.
5. Map supported problems to the most relevant heuristic.
6. Create a finding only when evidence supports the issue.
7. Assign severity 0–4 to the validated finding.
8. Identify the affected visual region.
9. Explain why the issue matters to the stated user goal.
10. Provide a concrete recommendation.

Do not automatically create 10 findings just because there are 10 heuristics.

## Risk hypothesis rules

A hypothesis may be based on:

- the user's stated goal;
- the importance of a journey step;
- visible interaction patterns;
- error/recovery states;
- system feedback patterns;
- navigation and information architecture cues;
- other observable signals in the captured experience.

A hypothesis should be labeled **Needs evidence** when the available evidence is insufficient.

Do not:

- present a hypothesis as a confirmed issue;
- assign final finding severity to an unresolved hypothesis;
- count unresolved hypotheses as findings;
- use numeric confidence as proof;
- invent user behavior that was not observed or supported.

## Risk validation

A predicted risk becomes **Risk validated** only when the captured experience contains supporting visual evidence.

Example:

```text
Predicted risk:
Submission feedback may be unclear.

Observed evidence:
Submit remains visually unchanged while processing.

Result:
Risk validated → finding created.
```

If the evidence is not sufficient:

```text
Predicted risk:
Recovery path may be unclear.

Observed evidence:
Insufficient evidence to establish the problem.

Result:
Needs evidence → remains a hypothesis.
```

## Severity

Severity applies to validated findings:

- 0 — Not a usability problem
- 1 — Cosmetic / low priority
- 2 — Minor usability problem
- 3 — Major usability problem
- 4 — Usability catastrophe

Severity should reflect the usability impact supported by the evidence and the context of the evaluated task. It should not be inferred merely from the presence of a heuristic mismatch.

## Evidence rule

Every validated finding should contain:

- Screen
- Highlight region
- Observable issue
- Evidence description
- Heuristic
- Heuristic rationale
- Severity
- User impact
- Recommendation

Avoid unsupported statements about users' actual behavior. When describing likely impact, clearly frame it as a potential consequence of the observed issue.

## Recommendation rule

The recommendation must directly address the identified issue and should remain connected to the evidence.

Example:

**Issue:** No visible feedback after selecting Submit.

**Recommendation:** Show immediate submission feedback and a clear completion state while the request is processed.

**Suggested improvement:** Disable Submit during processing and show “Submitting…” followed by a clear confirmation with a reference number.

## Multi-screen rule

Evaluate each screen individually while considering flow relationships.

Example:

```text
Login → Dashboard → Request details → Confirmation
```

A finding should identify the specific affected screen while noting relevant cross-screen context when necessary.

## Finding quality rule

Prefer fewer, well-supported findings over a large number of speculative findings.

## Human-review rule

All validated findings are candidates until reviewed by the UX designer.

Only Keep/Edit decisions enter the final report. Dismissed findings remain excluded.
