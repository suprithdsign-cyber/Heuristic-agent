# 05 — Finding / Risk Data Schema

The data model explicitly separates **risk hypotheses** from **validated findings**.

## Evaluation

```json
{
  "evaluationId": "eval-001",
  "goal": "Submit a service request",
  "screens": [],
  "riskHypotheses": [],
  "findings": [],
  "status": "in_review"
}
```

## Screen

```json
{
  "screenId": "screen-01",
  "name": "Confirmation",
  "url": "https://example.com/request/confirmation",
  "order": 3,
  "screenshot": "capture-reference",
  "status": "captured"
}
```

## Risk hypothesis

A risk hypothesis is not a finding and does not receive final finding severity.

```json
{
  "riskId": "risk-02",
  "screenId": "screen-01",
  "title": "Recovery path may be unclear after validation error",
  "reason": "The task depends on successful recovery from a failed submission.",
  "heuristicCandidates": [
    {
      "id": 9,
      "name": "Help users recognize, diagnose, and recover from errors"
    }
  ],
  "status": "needs_evidence",
  "evidence": null,
  "findingId": null
}
```

### Risk hypothesis status

- `needs_evidence`
- `validated`
- `not_supported`

Only `validated` hypotheses may create a finding.

## Validated finding

```json
{
  "findingId": "finding-01",
  "riskId": "risk-01",
  "screenId": "screen-01",
  "issue": "No visible feedback after selecting Submit.",
  "heuristic": {
    "id": 1,
    "name": "Visibility of system status"
  },
  "severity": 3,
  "evidence": "The Submit button and surrounding interface remain visually unchanged while the request is processed.",
  "highlight": {
    "x": 420,
    "y": 510,
    "width": 140,
    "height": 44
  },
  "observation": "The interface does not show clear progress or confirmation while the request is processed.",
  "impact": "Users may retry or leave without knowing whether the request succeeded.",
  "recommendation": "Show immediate submission feedback and a clear completion state while the request is processed.",
  "suggestedImprovement": "Disable Submit during processing and show 'Submitting…' followed by 'Request submitted' with a reference number.",
  "reviewStatus": "pending"
}
```

## Review status

- `pending`
- `kept`
- `edited`
- `dismissed`

## Evaluation status

- `draft`
- `setup`
- `clarification_required`
- `accessing`
- `analyzing`
- `risk_preview`
- `review`
- `completed`
- `error`

## Traceability rule

Whenever a finding originated from a prediction, retain the `riskId`. This allows the product to show:

```text
Prediction → Evidence → Validated finding → Human decision
```

## MVP rule

Keep the schema small. Do not add analytics, business-impact forecasting, automated redesign metadata, design-system metadata, or scoring models unless later required.
