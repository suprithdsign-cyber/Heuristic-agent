# 03 — Detailed Stage Specifications

These contracts define the exact behavior behind the simplified visible MVP journey.

## Stage 01 — Set up

**Purpose:** Start an evaluation with the minimum information needed.

**User action:** Enter one URL, multiple URLs/screens, or provide screenshots. State the evaluation goal when known.

**Agent behavior:** Understand the request, establish session state, and determine whether the target and goal are sufficiently clear.

**Required data:** Target, screenshots if supplied, user goal, session state.

**Agent instruction:**

> Identify the evaluation task, target, and user goal. Determine whether the request contains the minimum information required to proceed. Do not ask for unnecessary information.

**System action:** Validate input and initialize session.

**Output:** Evaluation context.

**Decision:** Ready → Analyze. Material ambiguity → ask one concise clarification.

**Fallback:** Missing/invalid target or essential input.

---

## Stage 02 — Analyze

**Purpose:** Retrieve the experience and produce evidence-grounded evaluation material.

**User action:** Wait/review useful progress.

**Agent behavior:** Capture the target, preserve screen ordering, inspect visible UI, evaluate against Nielsen's 10 heuristics, and identify potential risk areas.

**Required data:** Target resource, screenshots, heuristic rules, severity scale, finding schema.

**Agent instruction:**

> Retrieve the target experience and evaluate visible UI evidence against Nielsen's 10 usability heuristics. Identify observable issues and potential risk areas. Do not turn a prediction into a finding without supporting evidence.

**System action:** Load/capture screens and states; analyze visual evidence.

**Output:** Screens, evidence, risk hypotheses, and validated finding candidates.

**Decision:** → Risk Preview.

**Fallback:** If target access fails, use the documented recovery path.

---

## Stage 03 — Risk Preview

**Purpose:** Help the designer focus attention before reviewing the detailed findings.

**User action:** Inspect potential risk areas.

**Agent behavior:** Predict likely usability risk areas based on the stated goal, journey, interaction patterns, and available evidence.

**Required data:** User goal, screen map, captured evidence, heuristic rules.

**Agent instruction:**

> Identify potential usability risk areas that deserve closer inspection. Treat each as a hypothesis. Check for supporting visual evidence before creating a finding.

**System action:** Associate hypotheses with screens/regions and relevant heuristics.

**Output:** Risk hypotheses.

**Risk states:**

- `needs_evidence` — insufficient evidence to confirm the risk.
- `validated` — supporting evidence exists and the risk can become a finding.

**Important:** A risk hypothesis has no finding severity until it is validated.

**Decision:** Validated risks → Review. Needs-evidence risks remain outside the normal finding count.

---

## Stage 04 — Review Findings

**Purpose:** Preserve designer judgment and make each finding understandable at a glance.

**User action:** Keep, Edit, or Dismiss. Optionally request further inspection/retry.

**Agent behavior:** Present a self-contained validated finding.

**Required data:**

- screen;
- visual evidence;
- highlighted region;
- observation;
- heuristic;
- heuristic rationale;
- severity 0–4;
- user impact;
- recommendation;
- suggested improvement;
- originating risk hypothesis, when applicable.

**Agent instruction:**

> Present the finding with its evidence, heuristic, severity, impact, and recommendation together. Do not separate the evidence from the recommendation. Apply the designer's review decision.

**Output:** Reviewed finding state.

**Decision:**

- Keep → final report
- Edit → update → final report
- Dismiss → excluded
- Retry/inspect → relevant stage

---

## Stage 05 — Report

**Purpose:** Communicate the evaluation and create an actionable improvement plan without disconnecting evidence from findings.

**Agent behavior:** Build the report only from reviewed findings and synthesize the Improvement Plan from those findings.

**Output:** Final report.

**Primary report unit:** Finding.

**Report sections:**

1. Executive Summary
2. Findings & Evidence
3. Improvement Plan
4. Evaluation Context
5. Methodology

**Secondary utility:** Evidence Index may be used for navigation, but should not replace connected finding cards.

---

## Cross-cutting fallback

If the target is inaccessible, preserve the evaluation context and offer:

- Provide screenshot
- Edit URL
- Try again
- Go back

Do not create a separate dead-end error journey.

## Cross-cutting agent behavior

The agent should:

- ask only necessary questions;
- provide useful progress;
- ground claims in visible evidence;
- distinguish hypotheses from findings;
- preserve screen-to-finding traceability;
- keep the designer in control;
- avoid hidden reasoning disclosure.
