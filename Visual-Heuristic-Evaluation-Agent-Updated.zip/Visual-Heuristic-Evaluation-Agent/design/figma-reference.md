# Figma Reference

## Current source

Figma file:

https://www.figma.com/design/UkFGLSaPcxHiIz7JGYF5Ez/Heuristic-Analysis-Agent-%25E2%2580%2594-MVP?node-id=73-4

The current design reference for implementation is the **revised V5 MVP flow**.

## Current journey

```text
SET UP → ANALYZE → RISK PREVIEW → REVIEW → REPORT
```

## Current V5 frames

- `V5 01 — Set up`
- `V5 02 — Analyze`
- `V5 03 — Risk preview`
- `V5 04 — Review findings`
- `V5 05 — Report`

## Earlier explorations in the same file

The Figma file contains earlier V2, V3, V4, V5 exploration, and V6 work. These are design-history artifacts rather than competing product requirements.

### V2

Start review → Clarify flow → Analyze → Visual findings → Visual report → Fallback.

### V3

Reduced redundant setup and made clarification conditional.

### V4

Cleaned the MVP around a simple start/analyze/review/report structure with in-session fallback.

### V5 exploration

Explored Target → Goal → Analyze → Review → Report, predictive scope, release weighting, predicted impact, and follow-up prioritization.

### Revised V5

Retained the useful prediction concept but simplified it to:

```text
Set up → Analyze → Risk preview → Review → Report
```

Removed numeric confidence, predicted business impact, release optimization, and unnecessary conversational follow-up from the MVP.

### V6 exploration

Explored an even simpler:

```text
Set up → Analyze → Review → Report
```

The current package intentionally keeps **Risk preview** because it is the agreed value-add prediction layer for the revised V5 MVP.

## Critical visual rules

### Risk hypothesis vs finding

Use:

- **Potential risk** / **Needs evidence** for unresolved hypotheses.
- **Risk validated** for a hypothesis supported by evidence.
- **Finding** only after validation.

Avoid a UI state such as:

```text
Finding 02 of 04
Needs validation
```

when the item is not yet a validated finding.

### Finding card

A finding should keep these together:

- visual evidence;
- highlighted region;
- observation;
- heuristic;
- severity;
- why it matters;
- recommendation;
- suggested improvement;
- Keep / Edit / Dismiss.

### Report

Avoid disconnected:

```text
Evidence Gallery → Recommendations page
```

Prefer:

```text
Finding
 ├── Evidence
 ├── Observation
 ├── Heuristic
 ├── Severity
 ├── Impact
 └── Recommendation
```

The Improvement Plan then synthesizes those reviewed findings.

## Design principles

- Evidence before assertion.
- Prediction is not proof.
- Visual-first communication.
- Progressive disclosure.
- Human control.
- Connected evidence and recommendation.
- Minimal autonomous decision-making.
- No chain-of-thought disclosure.
