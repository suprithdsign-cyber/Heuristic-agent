# Visual Heuristic Evaluation Agent — MVP PRD

## 1. Product

A visual, evidence-first heuristic evaluation agent for UX/Product Designers.

The MVP accepts a live URL, one or more screens/URLs, or screenshots and evaluates the visible experience against Nielsen's 10 usability heuristics. The agent can predict likely usability risk areas, but a prediction is **not a finding** until visual evidence supports it. Validated findings are reviewed by the designer before entering the final report.

## 2. Problem

Traditional heuristic evaluations can be time-consuming and difficult to communicate because findings are often text-heavy and disconnected from the actual UI. Designers need a faster way to identify likely problem areas, inspect visual evidence, understand why an issue matters, and turn validated observations into actionable recommendations.

There is also a second problem for AI-assisted evaluation: an agent can produce plausible-sounding findings that are not sufficiently grounded in the interface. The MVP therefore needs a visible distinction between **prediction, evidence, validation, and human judgment**.

## 3. Primary user

UX Designer / Product Designer.

## 4. MVP goal

Enable a designer to:

1. Set up an evaluation with a target and user goal.
2. Let the agent understand the task and ask only necessary clarification.
3. Access/capture the target experience.
4. Analyze visible UI against Nielsen's 10 heuristics.
5. Preview predicted usability risk areas to help focus attention.
6. Validate predicted risks using visual evidence.
7. Review evidence-backed findings one by one.
8. Keep, edit, or dismiss findings.
9. Produce a visual report in which evidence, issue, heuristic, severity, impact, and recommendation remain connected.

## 5. Final visible MVP journey

```text
SET UP
  ↓
ANALYZE
  ↓
RISK PREVIEW
  ↓
REVIEW FINDINGS
  ↓
REPORT
```

Fallback is a continuation of the relevant stage rather than a separate product journey.

### Internal agent logic

```text
Understand intent
      ↓
Check required information
      ↓
Clarify only if needed
      ↓
Access / capture resource
      ↓
Evaluate visible evidence
      ↓
Predict / surface risk areas
      ↓
Validate risk hypotheses
      ↓
Human review
      ↓
Report
```

The internal logic is intentionally more detailed than the visible UI.

## 6. MVP capabilities

- Direct URL input.
- Multiple screen/URL input.
- Screenshot input/fallback.
- User-goal/intent understanding.
- Minimal clarification.
- Screen capture and ordering.
- Nielsen 10 heuristic evaluation.
- Visual evidence and highlighting.
- Risk prediction / risk preview.
- Explicit distinction between prediction and validated finding.
- Severity 0–4 for validated findings.
- User-impact explanation.
- Concrete recommendations.
- Finding-by-finding human review.
- Keep / Edit / Dismiss.
- Visual report.
- Improvement plan derived from reviewed findings.
- Essential access/error fallback.

## 7. Risk prediction principle

Risk prediction is the primary value-add introduced beyond a conventional heuristic checklist.

The agent may predict where usability risk is likely to exist based on the stated goal, captured journey, interaction patterns, and available visual evidence.

A risk prediction is a **hypothesis**. It must not be represented as a confirmed usability problem.

```text
RISK HYPOTHESIS
      ↓
CHECK VISUAL EVIDENCE
      ↓
Evidence supports risk?
   ┌───────────────┐
   │               │
  Yes        No / insufficient
   │               │
   ↓               ↓
RISK VALIDATED   NEEDS EVIDENCE
   │               │
   ↓               ↓
FINDING         Remains hypothesis
   │
   ↓
HUMAN REVIEW
```

### MVP prediction boundaries

Do **not** use in the MVP:

- numeric prediction confidence such as “86%”;
- predicted business impact such as “+9–14% task completion”;
- predicted ROI or conversion percentages;
- autonomous release-priority optimization;
- a conversational “what should engineering fix first?” decision engine.

These may be explored later, but the MVP should first establish trustworthy evidence-grounded evaluation.

## 8. Severity

Severity applies to a validated finding, not to an unresolved risk hypothesis.

- 0 — Not a usability problem
- 1 — Cosmetic / low priority
- 2 — Minor usability problem
- 3 — Major usability problem
- 4 — Usability catastrophe

## 9. Report principle

**A finding is the primary unit of the report.**

A validated finding should keep these together:

- Finding title / issue
- Screen
- Visual evidence
- Highlighted region
- Observation
- Heuristic
- Heuristic rationale
- Severity
- Why it matters / user impact
- Recommendation
- Suggested improvement
- Review status
- Optional trace to the originating risk hypothesis

### Report IA

```text
01 Executive Summary
02 Findings & Evidence
   └── Finding 01
       ├── Visual evidence
       ├── Observation
       ├── Heuristic
       ├── Severity
       ├── Why it matters
       ├── Recommendation
       └── Suggested improvement
03 Improvement Plan
04 Evaluation Context
05 Methodology
```

An Evidence Index can be provided as a secondary navigation utility, but evidence should not be separated from the finding in the primary report experience.

## 10. Human-control principle

The agent proposes evidence-backed findings. The UX designer remains in control of the final evaluation.

Only kept or edited findings enter the final report. Dismissed findings remain excluded.

The review state should make it obvious whether a risk is:

- a prediction/hypothesis;
- validated evidence;
- accepted by the designer;
- edited by the designer;
- dismissed by the designer.

## 11. Essential fallback

If a target cannot be accessed, the session should not lose its context.

Provide only the essential recovery paths:

- Provide screenshot
- Edit URL
- Try again / retry relevant access step
- Go back

Preserve the stated goal, target, and existing session information.

## 12. Non-goals

- Autonomous redesign.
- Automatic code/design changes.
- Complex conversational assistant.
- Design-system generation.
- Analytics platform.
- Numeric business-impact forecasting.
- Predicted task-completion percentages.
- Release-priority optimization engine.
- Unnecessary autonomous decisions.
- Exposing chain-of-thought.

## 13. Success criteria for the MVP

The prototype should demonstrate that a designer can:

- Start an evaluation without unnecessary setup.
- Understand what the agent is doing without seeing hidden reasoning.
- See predicted risk areas without confusing them with findings.
- Trace every validated finding to visual evidence.
- Distinguish **Needs evidence** from **Risk validated**.
- Review and control every finding before finalization.
- Read a report without switching between disconnected evidence and recommendation sections.
- Recover from an inaccessible target without losing the evaluation context.

## 14. Design principles

### Evidence before assertion

The agent should not convert a plausible prediction into a finding without supporting UI evidence.

### Progressive disclosure

The UI should expose the current decision and useful progress, not every internal agent step.

### Human control

The agent accelerates analysis; the designer owns the final judgment.

### Visual grounding

Findings should point directly to the affected screen and region.

### Connected reporting

The evidence and recommendation for one finding should be understandable at a glance.

### Minimal autonomy

Automate useful work, not decisions that require design judgment.
