# 02 — Consolidated End-to-End Agentic Experience

## Purpose

This document is the behavioral source of truth for the MVP interaction. It separates the **visible product journey** from the **internal agent workflow** so the experience remains simple without losing implementation detail.

## Current visible journey

```text
SET UP
   ↓
ANALYZE
   ↓
RISK PREVIEW
   ↓
REVIEW FINDINGS
   ↓
REPORT
```

## Internal agent workflow

```text
USER REQUEST
   ↓
UNDERSTAND INTENT
   ↓
CHECK REQUIRED INFORMATION
   ↓
Missing / ambiguous?
   ├── No → ACCESS RESOURCE
   └── Yes → CLARIFY ONE THING
                  ↓
             ACCESS RESOURCE
                  ↓
             ANALYZE VISIBLE UI
                  ↓
             SURFACE RISK HYPOTHESES
                  ↓
             VALIDATE WITH EVIDENCE
                  ↓
             PRESENT VALIDATED FINDINGS
                  ↓
             HUMAN REVIEW
                  ├── Keep
                  ├── Edit
                  └── Dismiss
                         ↓
                       REPORT
```

## Visible stage mapping

| Visible stage | Internal behavior | Designer sees |
|---|---|---|
| Set up | Start + understand intent + check required information + conditional clarification | Target, screenshots, goal, scope readiness |
| Analyze | Access resource + capture screens + evaluate UI + communicate useful status | Progress, screens captured, evidence collection |
| Risk preview | Surface risk hypotheses and explain validation boundary | Potential risk areas, not findings |
| Review | Present validated findings + human decision | Evidence, issue, heuristic, severity, impact, recommendation, Keep/Edit/Dismiss |
| Report | Persist reviewed decisions + synthesize improvement plan | Connected findings and evidence, improvement plan, context |

## Stage contracts

### 01 — Set up

**User goal/action:** Provide URL/screenshots and state the user goal.

**Agent behavior:** Interpret the request, establish the evaluation session, infer what can be inferred safely, and identify whether anything essential is missing.

**System/tool action:** Create session and validate basic input.

**Required data:** User request, target, optional screenshots, user goal, session state.

**Agent instruction:**

> Identify the evaluation task, target, and user goal. Determine whether the request contains the minimum information required to begin. Ask only for information that is genuinely necessary.

**Output:** Evaluation session + target + goal + scope readiness.

**Decision:** Ready → Analyze. Missing/ambiguous → one concise clarification within setup.

---

### 02 — Analyze

**User goal/action:** Let the agent inspect the experience.

**Agent behavior:** Access/capture the target, preserve screen order, inspect visible states, and evaluate against Nielsen's heuristics.

**System/tool action:** Load URL, capture screenshots/states, inspect evidence, create candidate risk hypotheses and validated findings where supported.

**Required data:** Target resource, screenshots, heuristic rules, severity scale, finding schema.

**Agent instruction:**

> Retrieve the target experience and evaluate the visible UI against Nielsen's 10 usability heuristics. Capture only observable evidence. Surface potential risk areas for focused validation. Do not treat predictions as findings.

**Output:** Captured screens, evidence, risk hypotheses, and candidate findings.

**Decision:** Analysis complete → Risk preview.

---

### 03 — Risk preview

**Purpose:** Add useful prediction without replacing evidence-based evaluation.

**User goal/action:** Understand where the agent expects usability risk before reviewing findings.

**Agent behavior:** Group likely risk areas based on the stated goal, journey, interaction patterns, and analysis. Clearly label them as hypotheses.

**System/tool action:** Associate each hypothesis with the relevant screen/area and the heuristics that should be checked.

**Agent instruction:**

> Identify potential usability risk areas that deserve closer inspection. Treat each as a hypothesis. Validate it against visible evidence before converting it into a finding.

**Output:** Risk hypothesis list.

**States:**

- **Needs evidence** — potential risk exists, but evidence is insufficient.
- **Risk validated** — supporting evidence exists; the issue may enter finding review.

**Critical rule:** An unresolved risk hypothesis must not appear as a normal finding.

**Decision:** Validated risks → Review. Unresolved risks remain hypotheses and may be inspected further without being counted as findings.

---

### 04 — Review findings

**User goal/action:** Validate the agent's evidence-backed findings and decide what belongs in the report.

**Agent behavior:** Present one finding at a time with all relevant information connected.

**Required data:** Screen, evidence/highlight, observation, heuristic, severity, impact, recommendation, optional originating risk hypothesis.

**Agent instruction:**

> Present each validated finding as a self-contained review unit. Keep visual evidence, observation, heuristic rationale, severity, impact, and recommendation together. Apply the designer's Keep, Edit, or Dismiss decision.

**Output:** Reviewed findings.

**Decision:**

- Keep → report
- Edit → update finding → report
- Dismiss → exclude from report
- Retry/inspect further → relevant previous stage

---

### 05 — Report

**User goal/action:** Understand the evaluation and decide what to act on.

**Agent behavior:** Present reviewed findings without disconnecting their evidence and recommendations. Synthesize an improvement plan from those same findings.

**Output:** Final report.

**Report structure:**

```text
Executive Summary
↓
Findings & Evidence
↓
Improvement Plan
↓
Evaluation Context
↓
Methodology
```

## Decision logic

### Intent / required information

```text
Is the target and user goal sufficiently clear?
├── Yes → Analyze
└── No → Ask one concise clarification
```

### Resource access

```text
Target accessible?
├── Yes → Analyze
└── No → Screenshot / Edit URL / Retry / Go back
```

### Risk prediction

```text
Potential risk identified
        ↓
Is there supporting visual evidence?
├── Yes → Risk validated → Finding review
└── No → Needs evidence → Remains hypothesis
```

### Finding generation

```text
Observable evidence + relevant heuristic
        ↓
Validated finding
```

No evidence → no finding.

### Human review

```text
Validated finding
├── Keep → Report
├── Edit → Updated finding → Report
├── Dismiss → Exclude
└── Retry / inspect → Relevant stage
```

## Agentic design rule

Expose:

- what the agent needs;
- what it is doing at a useful level;
- useful progress;
- visual evidence;
- the current result;
- user controls.

Do not expose private chain-of-thought.
